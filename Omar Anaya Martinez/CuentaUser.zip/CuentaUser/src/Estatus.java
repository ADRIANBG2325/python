public interface Estatus{
    public void evCalif();
    public void premio();
}
